Team Member Names:

Ahmed Yasser Hassanein 21-101006
Abdulrahman Khaled Salah 21-101079
Omar Mohamed El Abasery 21-101173
Omar Mohamed El Gohary 21-101082
Ammar Ahmed Fathy 21-101007

Package Description:

The program starts by validating the username and password for the Admin and Receptionists (if there is any).
Then, a menu pops up and a variety of choices are presented to the user logged in. In other words, the Admin gets a 
different variety of choices than the Receptionist due to its different functions and accessibility. 
After that, all input data are saved in a map that represents each defined class.

How to Run and Use the Program:

The user must select the "main.cpp" file and click the run button found on the top-right to create a .exe file, and
the terminal will open up and the steps mentioned in the previous section will pop up.