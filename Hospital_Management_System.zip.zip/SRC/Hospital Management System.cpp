#include <bits/stdc++.h>
#include <map>
#include <iterator>
#include <windows.h>
using namespace std;

class Human {
    public:
        Human()
        {

        }
        virtual void prescription();
        virtual void checkReports();
        virtual double getSalary();
        virtual void getAssignedToRooms();
        virtual bool checkRoomAvailability(string roomNum);
        virtual void bookRoom();
        virtual void generateBills();
        virtual string getID();
        virtual string getName();
        virtual string getPhoneNumber();
        virtual string getSpecialization();
        virtual string getDepartment();
    protected:
        string ID, name, phone_number;
        double salary;
};

string Human::getID(){
    return ID;
}

string Human::getName(){
    return name;
}

string Human::getPhoneNumber(){
    return phone_number;
}

string Human::getSpecialization(){
    return "specialization";
}

string Human::getDepartment(){
    return "department";
}

void Human::prescription() {

}

void Human::checkReports() {

}

double Human::getSalary() {
    return 1.0;
}

void Human::getAssignedToRooms() {

}

bool Human::checkRoomAvailability(string roomNum) {
    return true;
}

void Human::bookRoom() {

}

void Human::generateBills() {

}

class Department{
    public:
        Department(){

        }
        Department(string n, string rank, int p)
        {
            dep_name = n;
            highRank_ID = rank;
            dep_price = p;
        }
        void setID(int i);
        void setName(string n);
        void setRank(string r);
        void setDepPrice(int p);
        string getID();
        string getHighRankID();
        string getDepName();
        int getDepPrice();
    private:
        string ID, dep_name, highRank_ID;
        int dep_price;
};

void Department::setID(int i){
    ID = "Dep-" + to_string(i);
}

void Department::setName(string n){
    dep_name = n;
}

void Department::setRank(string r){
    highRank_ID = r;
}

void Department::setDepPrice(int p){
    dep_price = p;
}

string Department::getHighRankID(){
    return highRank_ID;
}

string Department::getDepName(){
    return dep_name;
}

string Department::getID(){
    return ID;
}

int Department::getDepPrice(){
    return dep_price;
}

class Doctor:public Human { 
    public:
        Doctor(){

        }
        Doctor(string n, string pn, string dep, string s, double sal) {
            name = n;
            phone_number = pn;
            department = dep;
            specialization = s;
            salary = sal;
            high_rank = false;
            occupancy = false;
        }
        void setName(string n);
        void setPhoneNumber(string pn);
        void setDepartment(string d);
        void setSpecialization(string s);
        void setID(int i);
        void setRank(bool rank);
        void setOccupancy(bool occ);
        void setSalary(double sal);
        string getID();
        string getName();
        string getPhoneNumber();
        string getDepartment();
        string getSpecialization();
        bool getRank();
        bool getOccupancy();
        void prescription();
        void checkReports();
        double getSalary();
    private:
        string specialization, department;
        bool high_rank, occupancy;
};

void Doctor::setID(int i) {
    ID = "D-" + to_string(i);
}

void Doctor::setName(string n){
    name = n;
}

void Doctor::setPhoneNumber(string pn){
    phone_number = pn;
}

void Doctor::setDepartment(string d){
    department = d;
}

void Doctor::setSpecialization(string s){
    specialization = s;
}

void Doctor::setRank(bool rank){
    high_rank = rank;
}

void Doctor::setOccupancy(bool occ){
    occupancy = occ;
}

void Doctor::setSalary(double sal){
    salary = sal;
}

string Doctor::getID(){
    return ID;
}

string Doctor::getName(){
    return name;
}

string Doctor::getPhoneNumber(){
    return phone_number;
}

string Doctor::getSpecialization(){
    return specialization;
}

string Doctor::getDepartment(){
    return department;
}

bool Doctor::getOccupancy(){
    return occupancy;
}

bool Doctor::getRank(){
    return high_rank;
}

void Doctor::prescription() {
    
}

void Doctor::checkReports() {
    cout << "report";
}

double Doctor::getSalary() {
    return salary;
}

class Nurse:public Human{
    public:
        Nurse(){

        }
        Nurse(string n, string pn, string dep, string s, double sal) {
            name = n;
            phone_number = pn;
            department = dep;
            specialization = s;
            salary = sal;
        }
        void setID(int i);
        void setName(string n);
        void setPhoneNumber(string pn);
        void setDepartment(string d);
        void setSpecialization(string s);
        void setSalary(double sal);
        string getID();
        string getName();
        string getPhoneNumber();
        string getDepartment();
        string getSpecialization();
        double getSalary();
        void getAssignedToRooms();
        void addNurseToRoom(string n);
        map<int,string> inRoom;

    private:
        string specialization, department;
        int inRooms = 0;
        
};

void Nurse::addNurseToRoom(string n)
{
    inRooms++;
    inRoom.insert(pair<int,string>(inRooms,n));
}

void Nurse::setID(int i) {
    ID = "N-" + to_string(i);
}

void Nurse::setName(string n){
    name = n;
}

void Nurse::setPhoneNumber(string pn){
    phone_number = pn;
}

void Nurse::setDepartment(string d){
    department = d;
}

void Nurse::setSpecialization(string s){
    specialization = s;
}

void Nurse::setSalary(double sal){
    salary = sal;
}

string Nurse::getID(){
    return ID;
}

string Nurse::getName(){
    return name;
}

string Nurse::getPhoneNumber(){
    return phone_number;
}

string Nurse::getSpecialization(){
    return specialization;
}

string Nurse::getDepartment(){
    return department;
}

double Nurse::getSalary() {
    return salary;
}

void Nurse::getAssignedToRooms() {

}

class Patient:public Human{
    public:
        Patient(){

        }
        Patient(string n, string pn, string ad, int ag, string g, string dname, bool in) {
            name = n;
            phone_number = pn;
            address = ad;
            age = ag;
            gender = g;
            department = dname;
            inpatient = in;
        }
        void setID(int i);
        void setName(string n);
        void setPhoneNumber(string pn);
        void setAddress(string ad);
        void setAge(int ag);
        void setGender(string g);
        void setInpatient(bool o);
        void setDepartment(string dname);
        void setDoctorResponsible(string dresponsible);
        string getName();
        string getID();
        string getPhoneNumber();
        string getAddress();
        string getGender();
        string getDepartment();
        bool getInpatient();
        int getAge();
    
    private:
        string address, gender, department;
        int age;
        bool inpatient;
};

void Patient::setID(int i){
    ID = "P-" + to_string(i);
}

void Patient::setName(string n){
    name = n;
}

void Patient::setInpatient(bool o){
    inpatient = o;
}

void Patient::setPhoneNumber(string pn){
    phone_number = pn;
}

void Patient::setAddress(string ad){
    address = ad;
}

void Patient::setAge(int ag){
    age = ag;
}

void Patient::setGender(string g){
    gender = g;
}

string Patient::getDepartment()
{
    return department;
}

string Patient::getName(){
    return name;
}

string Patient::getID(){
    return ID;
}

bool Patient::getInpatient(){
    return inpatient;
}

string Patient::getPhoneNumber(){
    return phone_number;
}

string Patient::getAddress(){
    return address;
}

int Patient::getAge(){
    return age;
}

string Patient::getGender()
{
    return gender;
}

class Receptionist:public Human{
    public:
        Receptionist(){

        }
        Receptionist(string n, string pn, string pw, double sal) {
            name = n;
            phone_number = pn;
            password = pw;
            salary = sal;
        }
        void setID(int i);
        void setName(string n);
        void setPhoneNumber(string pn);
        void setPassword(string d);
        void setSalary(double sal);
        string getID();
        string getName();
        string getPhoneNumber();
        string getPassword();
    private:
        string password;
};

void Receptionist::setID(int i) {
    ID = "R-" + to_string(i);
}

void Receptionist::setName(string n){
    name = n;
}

void Receptionist::setPhoneNumber(string pn){
    phone_number = pn;
}

void Receptionist::setPassword(string pw){
    password = pw;
}

void Receptionist::setSalary(double sal){
    salary = sal;
}

string Receptionist::getID(){
    return ID;
}

string Receptionist::getName(){
    return name;
}

string Receptionist::getPhoneNumber(){
    return phone_number;
}

string Receptionist::getPassword() {
    return password;
}

class Room
{
    public:
        Room(){

        }
        Room(string D, int B);
        void setID(int i);
        void setNurse();
        void updateNurse();
        void setOccupancy(bool o);
        string getID();
        string getNurse();
        string getDepartment();
        int getTotalBeds();
        int getFreeBeds();
        void addDoctor();
        void addPatientToRoom(Patient p);
        bool getOccupancy();
        string getDoctorResponsible();
        bool checkNurseinRoom();
        bool checkPatientinRoom();
        void updateFreeBeds();
        void setDoctorResponsible(string dresponsible);
        map<int,Patient> Beds_DB;

    private:
        string ID, responsible_Nurse, department, doctor_responsible;
        int total_beds, occupied_beds = 0, free_beds;
        bool occupancy, patientinside = false, nurseinside = false, doctorinside = false;
        
};

bool Room::checkPatientinRoom()
{
    return patientinside;
}

Room::Room(string D, int B)
{
    department = D;
    total_beds = B;
    free_beds = B;
}

string Room::getID(){
    return ID;
}

string Room::getDoctorResponsible(){
    return doctor_responsible;
}

void Room::setDoctorResponsible(string dresponsible){
    doctor_responsible = dresponsible;
    doctorinside = true;
}

void Room::setID(int i){
    ID = "R-" + department + "-" + to_string(i);
}

void Room::setOccupancy(bool o){
    occupancy = o;
}

void Room::setNurse()
{
    cout << "Who will be the responsible nurse? ";
    cin >> responsible_Nurse;

    nurseinside = true;
}

void Room::updateNurse()
{
    cout << "Who will be the new responsible nurse? ";
    cin >> responsible_Nurse;
}

string Room::getNurse()
{
    return responsible_Nurse;
}

void Room::addPatientToRoom(Patient p)
{
    occupied_beds++;
    free_beds--;
    Beds_DB.insert(pair<int,Patient>(occupied_beds,p));
    patientinside = true;
}

string Room::getDepartment()
{
    return department;
}

int Room::getTotalBeds()
{
    return total_beds;
}

int Room::getFreeBeds()
{
    return free_beds;
}

bool Room::getOccupancy(){
    return occupancy;
}

bool Room::checkNurseinRoom()
{
    return nurseinside;
}

void Room::updateFreeBeds()
{
    free_beds = total_beds - occupied_beds;
}

class Admin:public Room
{
    public:
        Admin()
        {
            do
            {
               char who;
                who = Login();
                if(who == 'a')
                    allOptions();
                else
                    receptionistOptions();
            }while(true);
                
        }
        char Login();
        string getUsername();
        string getPassword();

        //Accessors
        void optionsDoctor();
        void optionsNurses();
        void optionsReceptionist();
        void roomOptions();
        void allOptions();
        void receptionistOptions();
        

        //Add functions
        void addStaff();
        void addDepartment();
        void addRoom();
        void addPatient();
        void addPatientintoRoom();
        void addDoctorToRoom();

        //Show functions
        void showDepartment();
        void showPatient();
        void showRoom();
        void showDoctorInfo();
        void showNurseInfo();
        void showReceptionistInfo();
        void showStaff();
        

        //Delete functions
        void deleteStaff();
        void deleteDepartment();
        void deleteDoctorFromDepartment();
        
        //Update functions
        void updateStaff();
        void updateDepartment();
        void updatePatient();
         
        //Misc
        void Change_HighRank();
        bool checkDoctorAvailability(string doc_ID);
        
    private:
        string username = "ADMIN", password = "1234";
        map<string, string> Database;
        map<string, Doctor> Doctors_DB;
        map<string, Nurse> Nurses_DB;
        map<string, Receptionist> Receptionists_DB;
        map<string, Department> Departments_DB;
        map<string, Patient> Patients_DB;
        map<string, Room> Rooms_DB;
        
};

char Admin::Login()
{
    system("cls");
    string user, pass;
    cout << "Username: ";
    cin >> user;
    cout << "Password: ";
    cin >> pass;

    if(user == username && pass == password)
        return 'a';
    else
    {
        map<string,string>::iterator itr;
        for(itr = Database.begin(); itr != Database.end(); ++itr)
            if(itr->first == user && itr->second == pass)
                return 'r';
    }
}

void Admin::allOptions()
{
    system("cls");
    int choice;
    string message1 = "Welcome Mr/Ms ADMIN\
    \n\nMy name is J.A.C.K.I.E your personal assistor in your journy to own a hospital";
    for(int i = 0; i < message1.length(); i++)
    {
        cout << message1[i];
        Sleep(5);
    }
    do
    {
        string message2 = "\n\nIf you want to add staff press 1.\
    \nIf you want to show staff press 2.\
    \nIf you want to delete staff press 3.\
    \nIf you want to update staff press 4.\
    \nIf you want to search for a staff member press 5.\
    \nIf you want to add a department press 6.\
    \nIf you want to delete a department press 7.\
    \nIf you want to update a department press 8.\
    \nIf you want to logout press 0.\
    \n\nWhat do you want me to perform? ";

        for(int i = 0; i < message2.length(); i++)
        {
            cout << message2[i];
            Sleep(5);
        }
        cin >> choice;
        system("cls");

        if(choice == 1)
            addStaff();
        else if(choice == 2)
        {
            system("cls");
            int view_who;
            string message3 = "If you want to view doctor options press 1.\
            \nIf you want to view nurse options press 2.\
            \nIf you want to view receptionist options press 3.\
            \n\nWhat is it going to be? ";

            for(int i = 0; i < message3.length(); i++)
            {
                cout << message3[i];
                Sleep(5);
            }
            cin >> view_who;
            if(view_who == 1)
                optionsDoctor();
            else if(view_who == 2)
                optionsNurses();
            else if(view_who == 3)
                optionsReceptionist();
        }
        else if(choice == 3)
        {
            system("cls");
            deleteStaff();
        }
        else if(choice == 4)
        {
            updateStaff();
        }
        else if(choice == 5)
        {
            string ID;
            cout << "Enter the id of the staff member you want to search for: ";
            cin >> ID;

            map<string,Doctor>::iterator doc;
            for(doc = Doctors_DB.begin(); doc != Doctors_DB.end(); ++doc)
                if(doc->first == ID)
                {
                    cout << "\nData of staff ID " << doc->first << " is:\n";
                    cout << "Name: " << doc->second.getName() << endl;
                    cout << "Phone Number: " << doc->second.getPhoneNumber() << endl;
                    cout << "Department: " << doc->second.getDepartment() << endl;
                    cout << "Specialization: " << doc->second.getSpecialization() << endl;
                    cout << "High Rank: " << doc->second.getRank() << endl;
                    cout << "Salary: " << doc->second.getSalary() << endl;
                }
            map<string,Nurse>::iterator nur;
            for(nur = Nurses_DB.begin(); nur != Nurses_DB.end(); ++nur)
                if(nur->first == ID)
                {
                    cout << "\nData of staff ID " << nur->first << " is:\n";
                    cout << "Name: " << nur->second.getName() << endl;
                    cout << "Phone Number: " << nur->second.getPhoneNumber() << endl;
                    cout << "Department: " << nur->second.getDepartment() << endl;
                    cout << "Specialization: " << nur->second.getSpecialization() << endl;
                    cout << "Salary: " << nur->second.getSalary() << endl;
                }
            map<string,Receptionist>::iterator rec;
            for(rec = Receptionists_DB.begin(); rec != Receptionists_DB.end(); ++rec)
                if(rec->first == ID)
                {
                    cout << "\nData of staff ID " << rec->first << " is:\n";
                    cout << "Name: " << rec->second.getName() << endl;
                    cout << "Phone Number: " << rec->second.getPhoneNumber() << endl;
                    cout << "Password: " << rec->second.getPassword() << endl;
                    cout << "Salary: " << rec->second.getSalary() << endl;
                }
        }
        else if(choice == 6)
        {
            addDepartment();
        }
        else if(choice == 7)
        {
            deleteDepartment();
        }
        else if(choice == 8)
        {
            updateDepartment();
        }
                
            
    }while(choice != 0);
            
}


void Admin::receptionistOptions()
{
    char keep_going;
    do
    {
        cout << "No time to put something sorryyyyyy ";
        system("pause");
    } while (true);
    
}

void Admin::optionsDoctor()
{
    char keep_going;
    do
    {   
        //get info

        //set rank
        string ID, name;
        int choice;
        string message1 = "\nIf you want to get info then press 1.\
        If you want to set a specific doctor's rank then press 2.\n";

        for(int i = 0; i < message1.length(); i++)
        {
            cout << message1[i];
            Sleep(5);
        }
        cin >> choice;
        
        system("cls");
        
        if(choice == 1)
        {
            int getChoice;
            string message2 = "\nOkay so you've chose to get info\nIf you want to see all the info of a doctor press 1.\
            \nIf you want to get a specific doctor's name press 2.\
            \nIf you want to get a specific doctor's phone number press 3.\
            \nIf you want to get a specific doctor's department press 4.\
            \nIf you want to get a specific doctor's specialization press 5.\
            \nIf you want to get the occupancy of a specific doctor press 6.\
            \nIf you want to show a doctor's salary press 7.\
            \n\nSo what do you want me to do? ";

            for(int i = 0; i < message2.length(); i++)
            {
                cout << message2[i];
                Sleep(5);
            }
            cin >> getChoice;

            if(getChoice == 1)
            {
                showDoctorInfo();
            }
            else if(getChoice == 2)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getName() << endl;
                }
            }
            else if(getChoice == 3)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getPhoneNumber() << endl;
                }
            }
            else if(getChoice == 4)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getDepartment() << endl;
                }
            }
            else if(getChoice == 5)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getSpecialization() << endl;
                }
            }
            else if(getChoice == 6)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getOccupancy() << endl;
                }
            }
            else if(getChoice == 7)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getSalary() << endl;
                }
            }
        }
        else if(choice == 2)
        {
            
        }
        
        system("cls");
        cout << "Do you need anything from here? (y = yes & n = no) ";
        cin >> keep_going;
        system("cls");
    } while (keep_going == 'y');
}

void Admin::optionsNurses()
{
    char keep_going;
    do
    {
        int choice;
        string message1 = "\nIf you want to get info then press 1.\n";

        for(int i = 0; i < message1.length(); i++)
        {
            cout << message1[i];
            Sleep(5);
        }
        cin >> choice;
        
        system("cls");
        
        if(choice == 1)
        {
            int getChoice;
            string message2 = "\nOkay so you've chose to get info\nIf you want to see all the info of a nurse press 1.\
            \nIf you want to get a specific nurse's name press 2.\
            \nIf you want to get a specific nurse's phone number press 3.\
            \nIf you want to get a specific nurse's department press 4.\
            \nIf you want to get a specific nurse's specialization press 5.\
            \nIf you want to show a nurse's salary press 6.\
            \nIf you want to add a nurse to a room press 7.\
            \nIf you want to get all rooms a certain nurse is responsible for press 8.\
            \n\nSo what do you want me to do? ";

            for(int i = 0; i < message2.length(); i++)
            {
                cout << message2[i];
                Sleep(5);
            }
            cin >> getChoice;

            if(getChoice == 1)
            {
                showNurseInfo();
            }
            else if(getChoice == 2)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                        cout << "\nThe nurse's name is " << itr->second.getName() << endl;
                }
            }
            else if(getChoice == 3)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                        cout << "\nThe nurse's name is " << itr->second.getPhoneNumber() << endl;
                }
            }
            else if(getChoice == 4)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                        cout << "\nThe nurse's name is " << itr->second.getDepartment() << endl;
                }
            }
            else if(getChoice == 5)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                        cout << "\nThe nurse's name is " << itr->second.getSpecialization() << endl;
                }
            }
            else if(getChoice == 6)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                        cout << "\nThe nurse's name is " << itr->second.getSalary() << endl;
                }
            }
            else if(getChoice == 7)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                    {
                        string n = itr->second.getName();
                        itr->second.addNurseToRoom(n);
                    }    
                }
            }
            else if(getChoice == 8)
            {
                string nurse_ID;
                cout << "What's the nurse ID: ";
                cin >> nurse_ID;

                map<string,Nurse>::iterator itr;
                for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
                {
                    if(itr->first == nurse_ID)
                    {
                        
                    }
                }
            }
        }
        else if(choice == 2)
        {

        }
        
        system("cls");
        cout << "Do you need anything from here? (y = yes & n = no) ";
        cin >> keep_going;
        system("cls");
    } while (keep_going == 'y');
}

void Admin::optionsReceptionist()
{
    char keep_going;
    do
    {
        string ID, name;
        int choice;
        string message1 = "\nIf you want to get info then press 1.\n";

        for(int i = 0; i < message1.length(); i++)
        {
            cout << message1[i];
            Sleep(5);
        }
        cin >> choice;
        
        system("cls");
        
        if(choice == 1)
        {
            int getChoice;
            string message2 = "\nOkay so you've chose to get info\nIf you want to see all the info of a receptionist press 1.\
            \nIf you want to get a specific receptionist's name press 2.\
            \nIf you want to get a specific receptionist's phone number press 3.\
            \nIf you want to show a receptionist's salary press 4.\
            \n\nSo what do you want me to do? ";

            for(int i = 0; i < message2.length(); i++)
            {
                cout << message2[i];
                Sleep(5);
            }
            cin >> getChoice;

            if(getChoice == 1)
            {
                showDoctorInfo();
            }
            else if(getChoice == 2)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getName() << endl;
                }
            }
            else if(getChoice == 3)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getPhoneNumber() << endl;
                }
            }
            else if(getChoice == 4)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getDepartment() << endl;
                }
            }
            else if(getChoice == 5)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getSpecialization() << endl;
                }
            }
            else if(getChoice == 6)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getOccupancy() << endl;
                }
            }
            else if(getChoice == 7)
            {
                string Doc_ID;
                cout << "What's the doctor ID: ";
                cin >> Doc_ID;

                map<string,Doctor>::iterator itr;
                for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
                {
                    if(itr->first == Doc_ID)
                        cout << "\nThe doctor's name is " << itr->second.getSalary() << endl;
                }
            }
        }
        else if(choice == 2)
        {

        }
        
        system("cls");
        cout << "Do you need anything from here? (y = yes & n = no) ";
        cin >> keep_going;
        system("cls");
    } while (keep_going == 'y');
}

void Admin::roomOptions()
{ //add room, show room, add doctor to room, 

}


void Admin::showDoctorInfo()
{
    string one_or_all;
    cout << "Do you want to show an Individual or all? (one = Individual , all = All members) ";
    cin >> one_or_all;

    if(one_or_all == "one")
    {
        string ID, name;
        char choice;
        cout << "Would you like to search for a member by ID or name (i = ID, n = name) ";
        cin >> choice;
        choice = tolower(choice);
        if (choice == 'i')
        {
            cout << "What's that member's ID?";
            cin >> ID;
        } else if (choice == 'n')
        {
            cout << "What's that member's name";
            cin >> name;
        }
        map<string,Doctor>::iterator itr;
        for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
        {
            if(itr->first == ID || itr->second.getName() == name)
            {
                cout << "\nData of staff ID " << itr->first << " is:\n";
                cout << "Name: " << itr->second.getName() << endl;
                cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
                cout << "Department: " << itr->second.getDepartment() << endl;
                cout << "Specialization: " << itr->second.getSpecialization() << endl;
                cout << "High Rank: " << itr->second.getRank() << endl;
                cout << "Salary: " << itr->second.getSalary() << endl;
            }
        }
        system("pause");
    }
    else
    {
        map<string,Doctor>::iterator itr;
        for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
        {
            cout << "\nData of staff ID " << itr->first << " is:\n";
            cout << "Name: " << itr->second.getName() << endl;
            cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
            cout << "Department: " << itr->second.getDepartment() << endl;
            cout << "Specialization: " << itr->second.getSpecialization() << endl;
            cout << "High Rank: " << itr->second.getRank() << endl;
            cout << "Salary: " << itr->second.getSalary() << endl;
        }
        system("pause");
    }
}

void Admin::showNurseInfo()
{
    string one_or_all;
        cout << "\nDo you want to show an Individual or all? (one = Individual , all = All members) ";
        cin >> one_or_all;

        if(one_or_all == "one")
        {
            string ID, name;
            char choice;
            cout << "Would you like to search for a member by ID or name (i = ID, n = name) ";
            cin >> choice;
            choice = tolower(choice);
            if (choice == 'i'){
                cout << "What's that member's ID?";
                cin >> ID;
            } else if (choice == 'n'){
                cout << "What's that member's name";
                cin >> name;
            }
            map<string,Nurse>::iterator itr;
            for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
            {
                if(itr->first == ID || itr->second.getName() == name)
                {
                    cout << "\nData of staff ID " << itr->first << " is:\n";
                    cout << "Name: " << itr->second.getName() << endl;
                    cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
                    cout << "Department: " << itr->second.getDepartment() << endl;
                    cout << "Specialization: " << itr->second.getSpecialization() << endl;
                    cout << "Salary: " << itr->second.getSalary() << endl;
                }
            }
        }
    else
    {
        map<string,Nurse>::iterator itr;
        for(itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr)
        {
            cout << "\nData of staff ID " << itr->first << " is:\n";
            cout << "Name: " << itr->second.getName() << endl;
            cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
            cout << "Department: " << itr->second.getDepartment() << endl;
            cout << "Specialization: " << itr->second.getSpecialization() << endl;
            cout << "Salary: " << itr->second.getSalary() << endl;
        }
    }
}

void Admin::showReceptionistInfo()
{
    string one_or_all;
        cout << "\nDo you want to show an Individual or all? (one = Individual , all = All members) ";
        cin >> one_or_all;

        if(one_or_all == "one")
        {
            string ID, name;
            char choice;
            cout << "Would you like to search for a member by ID or name (i = ID, n = name) ";
            cin >> choice;
            choice = tolower(choice);
            if (choice == 'i'){
                cout << "What's that member's ID?";
                cin >> ID;
            } else if (choice == 'n'){
                cout << "What's that member's name";
                cin >> name;
            }
            map<string,Receptionist>::iterator itr;
            for(itr = Receptionists_DB.begin(); itr != Receptionists_DB.end(); ++itr)
            {
                if(itr->first == ID || itr->second.getName() == name)
                {
                    cout << "\nData of staff ID " << itr->first << " is:\n";
                    cout << "Name: " << itr->second.getName() << endl;
                    cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
                    cout << "Password: " << itr->second.getPassword() << endl;
                    cout << "Salary: " << itr->second.getSalary() << endl;
                }
            }
        }
        else
        {
            map<string,Receptionist>::iterator itr;
            for(itr = Receptionists_DB.begin(); itr != Receptionists_DB.end(); ++itr)
            {
                cout << "\nData of staff ID " << itr->first << " is:\n";
                cout << "Name: " << itr->second.getName() << endl;
                cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
                cout << "Password: " << itr->second.getPassword() << endl;
                cout << "Salary: " << itr->second.getSalary() << endl;
            }
        }
}    


string Admin::getUsername(){
    return username;
}

string Admin::getPassword(){
    return password;
}

void Admin::addStaff() {
    string name, phone_number, department, specialization, password;
    double salary; 
    char which_staff;
    int num_staff;

    string message1 = "Which staff member would you like to add? (d = doctor, n = nurse, r = receptionist) ";
    for(int i = 0; i < message1.size(); i++)
    {
        cout << message1[i];
        Sleep(5);
    }
    cin >> which_staff;
    system("cls");
    if (which_staff == 'd'){
        cout << "How many would you like to add? ";
        cin >> num_staff;
        int start = Doctors_DB.size();
        int end = num_staff + Doctors_DB.size();
        for (int i = start; i < end; i++) {
            cout << "\nEnter the name: ";
            cin >> name;
            cout << "Enter the phone number: ";
            cin >> phone_number;
            cout << "Enter the department: ";
            cin >> department;
            cout << "Enter the specialization: ";
            cin >> specialization;
            cout << "Enter the salary: ";
            cin >> salary;
            Doctor x(name, phone_number, department, specialization, salary);
            x.setID(Doctors_DB.size() + 1);
            Doctors_DB.insert(pair<string, Doctor>(x.getID(), x));
        }
    }
    else if (which_staff == 'n') {
        cout << "How many would you like to add? ";
        cin >> num_staff;
        int start = Nurses_DB.size();
        int end = num_staff + Nurses_DB.size();
        for (int i = start; i < end; i++) {
            cout << "Enter the name: ";
            cin >> name;
            cout << "Enter the phone number: ";
            cin >> phone_number;
            cout << "Enter the department: ";
            cin >> department;
            cout << "Enter the specialization: ";
            cin >> specialization;
            cout << "Enter the salary: ";
            cin >> salary;
            Nurse x(name, phone_number, department, specialization, salary);
            x.setID(Nurses_DB.size() + 1);
            Nurses_DB.insert(pair<string, Nurse>(x.getID(), x));
        }
    }
    else if (which_staff == 'r') {
        cout << "How many would you like to add? ";
        cin >> num_staff;
        int start = Receptionists_DB.size();
        int end = num_staff + Receptionists_DB.size();
        for (int i = start; i < end; i++) {
            cout << "Enter the name: ";
            cin >> name;
            cout << "Enter the phone number: ";
            cin >> phone_number;
            cout << "Enter the password: ";
            cin >> password;
            cout << "Enter the salary: ";
            cin >> salary;
            Receptionist x(name, phone_number, password, salary);
            x.setID(Receptionists_DB.size() + 1);
            Receptionists_DB.insert(pair<string, Receptionist>(x.getID(), x));
            Database.insert(pair<string, string>(x.getID(), x.getPassword()));
        }
    }
}

void Admin::deleteStaff()
{
    char choice_delete = 'y';
    while(choice_delete == 'y')
    {
        char choice_staff, which_staff;
        cout << "\nDo you want to delete staff members? (y or n) ";
        cin >> choice_staff;
        choice_staff = tolower(choice_staff);
        if (choice_staff == 'y') {
            cout << "Which staff member would you like to delete? (d = doctor, n = nurse, r = receptionist) ";
            cin >> which_staff;

            if(tolower(which_staff) == 'd')
            {
                string ID;
                cout << "What's the ID of the staff member you want to delete?";
                cin >> ID;

                Doctors_DB.erase(ID);
            }
            else if(tolower(which_staff) == 'n')
            {
                string ID;
                cout << "What's the ID of the staff member you want to delete?";
                cin >> ID;

                Nurses_DB.erase(ID);
            }
            else if(tolower(which_staff) == 'n')
            {
                string ID;
                cout << "What's the ID of the staff member you want to delete?";
                cin >> ID;

                Receptionists_DB.erase(ID);
            }
        }

        cout << "\nDo you want to delete another staff member?";
        cin >> choice_delete;
    }

}

void Admin::updateStaff() {
    string name, phone_number, department, specialization;
    double salary;
    char choice_staff;
    cout << "Which staff member would you like to update? (d = doctor, n = nurse, r = receptionist) ";
    cin >> choice_staff;
    if (choice_staff == 'd') {
        system("cls");
        string choice_ID, choice_update;
        cout << "\nEnter the ID of the staff member: ";
        cin >> choice_ID;
        cout << "Enter the element to update: (n = name, pn = phone number, d = department, s = specialization, sal = salary, all = all elements) ";
        cin >> choice_update;
        //ne3mel validate lel id law mawgod yekamel law mesh mawgod maykamel4
        map<string,Doctor>::iterator itr;
        for (itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr){
            if (itr->first == choice_ID){
                if (choice_update == "n"){
                    cout << "Enter the name: ";
                    cin >> name;
                    itr->second.setName(name);
                } else if (choice_update == "pn"){
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    itr->second.setPhoneNumber(phone_number);
                } else if (choice_update == "d"){
                    cout << "Enter the department: ";
                    cin >> department;
                    itr->second.setDepartment(department);
                } else if (choice_update == "s"){
                    cout << "Enter the specialization: ";
                    cin >> specialization;
                    itr->second.setSpecialization(specialization);
                } else if (choice_update == "sal"){
                    cout << "Enter the salary: ";
                    cin >> salary;
                    itr->second.setSalary(salary);
                } else if(choice_update == "all"){
                    cout << "Enter the name: ";
                    cin >> name;
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    cout << "Enter the department: ";
                    cin >> department;
                    cout << "Enter the specialization: ";
                    cin >> specialization;
                    cout << "Enter the salary: ";
                    cin >> salary;
                    Doctor x(name, phone_number, department, specialization, salary);
                    Doctors_DB[choice_ID] = x;
                }
            }
        }
    } 
    else if (choice_staff == 'n') 
    {
        system("cls");
        string choice_ID, choice_update;
        cout << "\nEnter the ID of the staff member: ";
        cin >> choice_ID;
        cout << "Enter the element to update: (n = name, pn = phone number, d = department, s = specialization, sal = salary, all = all elements) ";
        cin >> choice_update;
        //ne3mel validate lel id law mawgod yekamel law mesh mawgod maykamel4
        map<string,Nurse>::iterator itr;
        for (itr = Nurses_DB.begin(); itr != Nurses_DB.end(); ++itr){
            if (itr->first == choice_ID){
                if (choice_update == "n"){
                    cout << "Enter the name: ";
                    cin >> name;
                    itr->second.setName(name);
                } else if (choice_update == "pn"){
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    itr->second.setPhoneNumber(phone_number);
                } else if (choice_update == "d"){
                    cout << "Enter the department: ";
                    cin >> department;
                    itr->second.setDepartment(department);
                } else if (choice_update == "s"){
                    cout << "Enter the specialization: ";
                    cin >> specialization;
                    itr->second.setSpecialization(specialization);
                } else if (choice_update == "sal"){
                    cout << "Enter the salary: ";
                    cin >> salary;
                    itr->second.setSalary(salary);
                } else if(choice_update == "all"){
                    cout << "Enter the name: ";
                    cin >> name;
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    cout << "Enter the department: ";
                    cin >> department;
                    cout << "Enter the specialization: ";
                    cin >> specialization;
                    cout << "Enter the salary: ";
                    cin >> salary;
                    Nurse x(name, phone_number, department, specialization, salary);
                    Nurses_DB[choice_ID] = x;
                }
            }
        }
    } 
    else if (choice_staff == 'r')
    {
        system("cls");
        string choice_ID, choice_update;
        cout << "\nEnter the ID of the staff member: ";
        cin >> choice_ID;
        cout << "Enter the element to update: (n = name, pn = phone number, pw = password, sal = salary, all = elements) ";
        cin >> choice_update;
        //ne3mel validate lel id law mawgod yekamel law mesh mawgod maykamel4
        map<string,Receptionist>::iterator itr;
        for (itr = Receptionists_DB.begin(); itr != Receptionists_DB.end(); ++itr){
            if (itr->first == choice_ID){
                if (choice_update == "n"){
                    cout << "Enter the name: ";
                    cin >> name;
                    itr->second.setName(name);
                } else if (choice_update == "pn"){
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    itr->second.setPhoneNumber(phone_number);
                } else if (choice_update == "pw"){
                    cout << "Enter the password: ";
                    cin >> password;
                    itr->second.setPassword(password);
                } else if (choice_update == "sal"){
                    cout << "Enter the salary: ";
                    cin >> salary;
                    itr->second.setSalary(salary);
                } else if (choice_update == "all") {
                    cout << "Enter the name: ";
                    cin >> name;
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    cout << "Enter the password: ";
                    cin >> password;
                    cout << "Enter the salary: ";
                    cin >> salary;
                    Receptionist x(name, phone_number, password, salary);
                    Receptionists_DB[choice_ID] = x;
                }
            }
        }
    } else {
        cout << "You entered a wrong staff member!";
    }
}

//function changed
void Admin::showDepartment()
{
    string one_or_all;
    cout << "\nDo you want to show a single department or all? (one = Individual , all = All members) ";
    cin >> one_or_all;

    if(one_or_all == "one")
    {
        string dep_ID;
        cout << "What's that department ID?";
        cin >> dep_ID;
        map<string,Department>::iterator itr;
        for(itr = Departments_DB.begin(); itr != Departments_DB.end(); ++itr)
        {
            if(itr->first == dep_ID)
            {
                cout << "\nData of department ID " << itr->first << " is:\n";
                cout << "Name: " << itr->second.getDepName() << endl;
                cout << "Price of an appointment in the department: "
                << itr->second.getDepPrice() << endl;
                cout << "Data of department doctors: ";
                map<string,Doctor>::iterator itr_2;
                for (itr_2 = Doctors_DB.begin(); itr_2 != Doctors_DB.end(); ++itr_2){
                    if (itr_2->second.getRank()){
                        cout << "\n1- Data of High Rank Doctor ID " << itr_2->first << " is:\n";
                        cout << "Name: " << itr_2->second.getName() << endl;
                        cout << "Phone Number: " << itr_2->second.getPhoneNumber() << endl;
                        cout << "Specialization: " << itr_2->second.getSpecialization() << endl;
                        break;
                    }
                }
                int counter = 1;
                for (itr_2 = Doctors_DB.begin(); itr_2 != Doctors_DB.end(); ++itr_2){
                    if (!(itr_2->second.getRank())){
                        counter++;
                        cout << counter << "- Data of Doctor ID " << itr_2->first << " is:\n";
                        cout << "Name: " << itr_2->second.getName() << endl;
                        cout << "Phone Number: " << itr_2->second.getPhoneNumber() << endl;
                        cout << "Specialization: " << itr_2->second.getSpecialization() << endl;
                    }
                }
            }
        }
    }
    else
    {
        map<string,Department>::iterator itr;
        for(itr = Departments_DB.begin(); itr != Departments_DB.end(); ++itr)
        {
                cout << "\nData of department ID " << itr->first << " is:\n";
                cout << "Name: " << itr->second.getDepName() << endl;
                cout << "High Rank Doctor: " << itr->second.getHighRankID() << endl;
                cout << "Price of an appointment in the department: "
                << itr->second.getDepPrice() << endl;
        }
    }
}

//function changed

void Admin::addDepartment(){
    string dep_name, highRank_ID;
    int num_departments, department_price;
    cout << "How many departments would you like to add? ";
    cin >> num_departments;
    int start = Departments_DB.size();
    int end = num_departments + Departments_DB.size();
    for (int i = start; i < end; i++) {
        cout << "What's the department name? ";
        cin >> dep_name;
        cout << "Who's the high ranked Doctor in the department? (ID) ";
        cin >> highRank_ID;
        cout << "What's the price for an appointment in the department? ";
        cin >> department_price;
        Department x(dep_name, highRank_ID, department_price);
        map<string,Doctor>::iterator itr;
        for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr){
            if(itr->second.getDepartment() == x.getDepName() && itr->second.getID() == x.getHighRankID()){
                itr->second.setRank(true);
            }
        }
        x.setID(Departments_DB.size() + 1);
        Departments_DB.insert(pair<string, Department>(x.getID(), x));
    }
}

// function changed

void Admin::updateDepartment(){
    string dep_name, highRank_ID, choice_department, choice_update;
    int department_price;
    cout << "Enter the ID of the department you would like to update: ";
    cin >> choice_department;
    cout << "Enter the element to update: (n = name, r = high rank doctor, a = appointment price, all = all elements) ";
    cin >> choice_update;
    map<string,Department>::iterator itr;
    for (itr = Departments_DB.begin(); itr != Departments_DB.end(); ++itr){
        if (choice_update == "n"){
            cout << "What's the department name? ";
            cin >> dep_name;
            itr->second.setName(dep_name);
        } else if(choice_update == "r"){
            cout << "Who's the high ranked Doctor in the department? (ID) ";
            cin >> highRank_ID;
            itr->second.setName(highRank_ID);
        } else if(choice_update == "a"){
            cout << "What's the price for an appointment in the department? ";
            cin >> department_price;
            itr->second.setDepPrice(department_price);
        }else if(choice_update == "all"){
            cout << "What's the department name? ";
            cin >> dep_name;
            cout << "Who's the high ranked Doctor in the department? (ID) ";
            cin >> highRank_ID;
            Department x(dep_name, highRank_ID, department_price);
            Departments_DB[choice_department] = x;
        }
    }
}

void Admin::deleteDepartment() // pay attention
{
    string choice_department, dep_name;
    cout << "Enter the ID of the department you would like to delete: ";
    cin >> choice_department;
    map<string,Department>::iterator itr;
    for(itr = Departments_DB.begin(); itr != Departments_DB.end(); ++itr)
    {
        if (itr->first == choice_department)
        {
            dep_name = itr->second.getDepName();
        }
    }
    Departments_DB.erase(choice_department);
}

void Admin::deleteDoctorFromDepartment()
{
    string ID_Dep, ID_Doc;
    cout << "\nWhat's the ID of the department you want to delete the doctor from? ";
    cin >> ID_Dep;
    
    map<string,Department>::iterator itr;
    for(itr = Departments_DB.begin(); itr != Departments_DB.end(); ++itr)
    {
        if(itr->first == ID_Dep)
        {
            cout << "\nWhat's the ID of the doctor you want to delete from department " << itr->second.getDepName() << "? ";
            cin >> ID_Doc;
            
            Doctors_DB.erase(ID_Doc);
        }
    }
}

void Admin::Change_HighRank(){
    string ID, doc_ID;
    cout << "Which department would you like to change its High Rank Doctor? (ID)";
    cin >> ID;
    cout << "Which doctor do you want to be the High Rank? (ID) ";
    cin >> doc_ID;
    map<string,Department>::iterator itr;
    for(itr = Departments_DB.begin(); itr != Departments_DB.end(); ++itr){
        if(itr->first == ID){
            map<string,Doctor>::iterator itr_2;
            for(itr_2 = Doctors_DB.begin(); itr_2 != Doctors_DB.end(); ++itr){
                if(itr_2->second.getRank() == true){
                    itr_2->second.setRank(false); 
                }
                if (itr_2->second.getID() == doc_ID){
                    itr_2->second.setRank(true);
                }
            }
        }
    }
}

void Admin::addPatient(){
    string name, phone_number, address, gender, department;
    int age, num_patient;
    char inpatient_choice; 
    cout << "How many patients would you like to add? ";
    cin >> num_patient;
    int start = Patients_DB.size();
    int end = num_patient + Patients_DB.size();
    for (int i = start; i < end; i++) {
        cout << "Enter the name: ";
        cin >> name;
        cout << "Enter the phone number: ";
        cin >> phone_number;
        cout << "Enter the address: ";
        cin >> address;
        cout << "Enter the age: ";
        cin >> age;
        cout << "Enter the gender: ";
        cin >> gender;
        cout << "Enter the department: ";
        cin >> department;
        cout << "Inpatient or not? (y = yes, n = no) ";
        cin >> inpatient_choice;
        if (inpatient_choice == 'y')
            inpatient_choice = true;
        else
            inpatient_choice = false;
        Patient x(name, phone_number, address, age, gender, department, inpatient_choice);
        x.setID(Patients_DB.size() + 1);
        Patients_DB.insert(pair<string, Patient>(x.getID(), x));
        cout << "\nCongrats your ID is " << x.getID() << ". Please remember it, you'll need it alot around here!\n";
    }
}

void Admin::showPatient(){
    cout << "Enter ID to search for: ";
    string ID;
    cin >> ID;
    map<string,Patient>::iterator itr;
    for(itr = Patients_DB.begin(); itr != Patients_DB.end(); ++itr)
    {
        if(itr->first == ID)
        {
            cout << "Data of Patient ID " << itr->first << " is:\n";
            cout << "Name: " << itr->second.getName() << endl;
            cout << "Phone Number: " << itr->second.getPhoneNumber() << endl;
            cout << "Adress: " << itr->second.getAddress() << endl;
            cout << "Age: " << itr->second.getAge() << endl;
            cout << "Gender: " << itr->second.getGender() << endl;
            cout << "Department: " << itr->second.getDepartment() << endl;
            cout << "Inpatient: " << itr->second.getInpatient() << endl;
        }
    }
}

/*
void Admin::updatePatient()//lesa ma5lset4
{
    string choice_ID, name, phone_number, choice_update, address, gender;
    int age;
    cout << "\nEnter the Patient ID: ";
    cin >> choice_ID;
        cout << "Enter the element to update: (n = name, pn = phone number, ad = address, ag = age, g = gender, all = all elements) ";
        cin >> choice_update;
        //ne3mel validate lel id law mawgod yekamel law mesh mawgod maykamel4
        map<string,Patient>::iterator itr;
        for (itr = Patients_DB.begin(); itr != Patients_DB.end(); ++itr)
        {
            if (itr->first == choice_ID){
                if (choice_update == "n"){
                    cout << "Enter the name: ";
                    cin >> name;
                    itr->second.setName(name);
                } else if (choice_update == "pn"){
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    itr->second.setPhoneNumber(phone_number);
                } else if (choice_update == "ad"){
                    cout << "Enter the address: ";
                    cin >> address;
                    itr->second.setAddress(address);
                } else if (choice_update == "a"){
                    cout << "Enter the age: ";
                    cin >> age;
                    itr->second.setAge(age);
                } else if (choice_update == "g"){
                    cout << "Enter the salary: ";
                    cin >> salary;
                    itr->second.setSalary(salary);
                } else if(choice_update == "all"){
                    cout << "Enter the name: ";
                    cin >> name;
                    cout << "Enter the phone number: ";
                    cin >> phone_number;
                    cout << "Enter the department: ";
                    cin >> department;
                    cout << "Enter the specialization: ";
                    cin >> specialization;
                    cout << "Enter the salary: ";
                    cin >> salary;
                    Doctor x(name, phone_number, department, specialization, salary);
                    Doctors_DB[choice_ID] = x;
                }
            }
        }
}*/

void Admin::addPatientintoRoom()
{
    string room_ID, patient_ID;
    char add = 'y', room = 'y';
    do
    {
        cout << "\nWhat's the room that you want to add patients to? ";
        cin >> room_ID;

        do
        {
            map<string,Room>::iterator itr;
            for(itr = Rooms_DB.begin(); itr != Rooms_DB.end(); ++itr)
            {
                if(itr->first == room_ID)
                {
                    cout << "\nEnter the id of the patient you want to add: ";
                    cin >> patient_ID;

                    map<string,Patient>::iterator itr_2;
                    for(itr_2 = Patients_DB.begin(); itr_2 != Patients_DB.end(); ++itr_2)
                    {
                        if(itr_2->first == patient_ID)
                        {
                            itr->second.addPatientToRoom(itr_2->second);
                        }
                    }
                }
                else
                    cout << "There is no room with this ID!\nYou gotta stop belittling me :(\n";
            }

            cout << "Do you still want to another patient to room " << room_ID << " ? (y = yes & n = no)";
            cin >> room;

        } while(room == 'y');

        cout << "Do you want to add patients into another room? (y = yes & n = no) ";
        cin >> add;

    } while(add == 'y');
    
}

void Admin::addDoctorToRoom()
{
    string room_ID, doc_ID;
    cout << "\nEnter the id of the room you want to assign a doctor to: ";
    cin >> room_ID;
    map<string,Room>::iterator itr;
    for(itr = Rooms_DB.begin(); itr != Rooms_DB.end(); ++itr)
    {
        if(itr->first == room_ID)
        {
            cout << "What's the ID of the doctor you want to assign to the " << itr->first << " room? ";
            cin >> doc_ID;

            itr->second.setDoctorResponsible(doc_ID);
        }
    }

}

void Admin::addRoom()
{
    string department, nurse_responsible;
    int num_room, bed_in_room;
    cout << "How many rooms would you like to add? ";
    cin >> num_room;
    int start = Rooms_DB.size();
    int end = num_room + Rooms_DB.size();
    for (int i = start; i < end; i++)
    {
        cout << "\nWhich department is this room in? ";
        cin >> department;
        cout << "How many beds are present in the room? ";
        cin >> bed_in_room;

        Room x(department,bed_in_room);
        x.setID(Rooms_DB.size() + 1);
        Rooms_DB.insert(pair<string,Room>(x.getID(),x));
        cout << "\nThis room's ID is " << x.getID() << endl;
    }
}

bool Admin::checkDoctorAvailability(string doc_ID){
    map<string,Doctor>::iterator itr;
    for(itr = Doctors_DB.begin(); itr != Doctors_DB.end(); ++itr)
    {
        if(itr->first == doc_ID && itr->second.getOccupancy())
        {
            return false; // not available
        }
    }
    return true; // available
}

void Admin::showRoom()
{
    string one_or_all;
    cout << "Do you want to show an individual or all? (one = Individual , all = All members) ";
    cin >> one_or_all;

    if(one_or_all == "all")
    {
        map<string,Room>::iterator itr;
        for(itr = Rooms_DB.begin(); itr != Rooms_DB.end(); ++itr)
        {
            cout << "\nRoom ID: " << itr->first << "\nRoom info:\n";
            cout << "In department: " << itr->second.getDepartment() << endl;
            cout << "Has " << itr->second.getTotalBeds() << " beds.\n";
            cout << "Has " << itr->second.getFreeBeds() << " free beds.\n";
            if(itr->second.checkNurseinRoom())
                cout << "Nurse responsible for this room is: " << itr->second.getNurse() << endl;
            if(itr->second.checkPatientinRoom())
            {
                cout << "This room has patient(s) of ID: " << endl;
                
                map<int,Patient>::iterator itr_2;
                for(itr_2 = itr->second.Beds_DB.begin(); itr_2 != itr->second.Beds_DB.end(); ++itr_2)
                    cout << "P-" << itr_2->first << " ";
                cout << endl;
            }
        }
    }
    else
    {
        string ID;
        cout << "What's the room ID that u want to show it's info? ";
        cin >> ID;
        
        map<string,Room>::iterator itr;
        for(itr = Rooms_DB.begin(); itr != Rooms_DB.end(); ++itr)
        {
            if(itr->first == ID)
            {
                cout << "\nRoom info:\n";
                cout << "In department: " << itr->second.getDepartment() << endl;
                cout << "Has " << itr->second.getTotalBeds() << " beds.\n";
                cout << "Has " << itr->second.getFreeBeds() << " free beds.\n";
                if(itr->second.checkNurseinRoom())
                    cout << "Nurse responsible for this room is: " << itr->second.getNurse() << endl;
                //if(checkPatientinRoom == true)
                    //cout << "This room has a patient of ID: " << itr->second.getPatient() << endl; 
            }
        }
    }
}

int main(void)
{
    Admin start;
    
    return 0;
}